function [sam_contours] = extract_2D_Boundaries(sparse_2D_points)

%% Anirban Chakraborty, Electrical Engineering, University of California, Riverside.

sam_contours = cell(length(sparse_2D_points),1);
for i = 1:length(sparse_2D_points)
    points = [];
    for j = 1:length(sparse_2D_points{i})
        points = [points; sparse_2D_points{i}{j}];
    end;
    points = unique(points, 'rows');
    sam_contours{i} = get2DBoundary(points, 'union');
end;

return;