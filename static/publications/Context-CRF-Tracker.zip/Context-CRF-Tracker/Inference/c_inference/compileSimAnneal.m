mex -O sim_anneal.cpp fillMethods.cpp InferenceAlgorithm.cpp MonteCarlo.cpp Metropolis.cpp MRF.cpp PottsMRF.cpp Region.cpp RegionLevel.cpp
